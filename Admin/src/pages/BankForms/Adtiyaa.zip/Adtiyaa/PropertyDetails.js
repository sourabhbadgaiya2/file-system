import React, { useState } from 'react';

const PropertyDetails = ({ onDataChange }) => {
  const [isOpen, setIsOpen] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    onDataChange(prev => ({ ...prev, [name]: value }));
  };

  return (
    <div className="accordion-item mb-4">
      <div
        className="accordion-header p-3 border rounded"
        style={{ backgroundColor: "#30384B", cursor: "pointer" }}
        onClick={() => setIsOpen(!isOpen)}
      >
        <div className="d-flex justify-content-between align-items-center text-white">
          <h4 className="m-0">Property Details</h4>
          <button
            type="button"
            className="btn btn-light btn-sm"
            onClick={(e) => {
              e.stopPropagation();
              setIsOpen(!isOpen);
            }}
          >
            {isOpen ? "Close" : "Edit"}
          </button>
        </div>
      </div>
      {isOpen && (
        <div className="accordion-body p-3 border rounded mt-2" style={{ backgroundColor: "#f8f9fa" }}>
          <div className="card-body">
            <div className="row">
              <div className="col-md-6">
                <div className="mb-3">
                  <label className="form-label">Occupancy</label>
                  <select 
                    className="form-select" 
                    name="occupancy"
                    onChange={handleChange}
                  >
                    <option value="Occupied">Occupied</option>
                    <option value="Vacant">Vacant</option>
                  </select>
                </div>
              </div>
              <div className="col-md-6">
                <div className="mb-3">
                  <label className="form-label">Occupied By</label>
                  <input 
                    type="text" 
                    className="form-control" 
                    name="occupiedBy"
                    onChange={handleChange}
                  />
                </div>
              </div>
            </div>

            <div className="row">
              <div className="col-md-6">
                <div className="mb-3">
                  <label className="form-label">Occupied Since</label>
                  <input 
                    type="text" 
                    className="form-control" 
                    name="occupiedSince"
                    onChange={handleChange}
                  />
                </div>
              </div>
              <div className="col-md-6">
                <div className="mb-3">
                  <label className="form-label">Name of the Occupant</label>
                  <input 
                    type="text" 
                    className="form-control" 
                    name="occupantName"
                    defaultValue="AMAN PATIDAR"
                    onChange={handleChange}
                  />
                </div>
              </div>
            </div>

            <div className="row">
              <div className="col-md-6">
                <div className="mb-3">
                  <label className="form-label">Property Demarcated</label>
                  <select 
                    className="form-select" 
                    name="propertyDemarcated"
                    onChange={handleChange}
                  >
                    <option value="Yes">Yes</option>
                    <option value="Partially">Partially</option>
                    <option value="No">No</option>
                  </select>
                </div>
              </div>
              <div className="col-md-6">
                <div className="mb-3">
                  <label className="form-label">Property Identification</label>
                  <select 
                    className="form-select" 
                    name="propertyIdentification"
                    onChange={handleChange}
                  >
                    <option value="YES">YES</option>
                    <option value="NO">NO</option>
                  </select>
                </div>
              </div>
            </div>

            <div className="row">
              <div className="col-md-6">
                <div className="mb-3">
                  <label className="form-label">Identification through</label>
                  <input 
                    type="text" 
                    className="form-control" 
                    name="identificationThrough"
                    defaultValue="LOCAL ENQUIRY"
                    onChange={handleChange}
                  />
                </div>
              </div>
              <div className="col-md-6">
                <div className="mb-3">
                  <label className="form-label">Project Category</label>
                  <select 
                    className="form-select" 
                    name="projectCategory"
                    onChange={handleChange}
                  >
                    <option value="A">A</option>
                    <option value="B">B</option>
                    <option value="C">C</option>
                    <option value="D">D</option>
                    <option value="A+">A+</option>
                    <option value="Not Applicable">Not Applicable</option>
                  </select>
                </div>
              </div>
            </div>

            <div className="row">
              <div className="col-md-6">
                <div className="mb-3">
                  <label className="form-label">Flat Type</label>
                  <select 
                    className="form-select" 
                    name="flatType"
                    onChange={handleChange}
                  >
                    <option value="Normal">Normal</option>
                    <option value="Duplex">Duplex</option>
                    <option value="Not applicable">Not applicable</option>
                  </select>
                </div>
              </div>
              <div className="col-md-6">
                <div className="mb-3">
                  <label className="form-label">Flat Configuration</label>
                  <input 
                    type="text" 
                    className="form-control" 
                    name="flatConfiguration"
                    defaultValue="NA"
                    onChange={handleChange}
                  />
                </div>
              </div>
            </div>

            <div className="row">
              <div className="col-md-6">
                <div className="mb-3">
                  <label className="form-label">Property Holding</label>
                  <select 
                    className="form-select" 
                    name="propertyHolding"
                    onChange={handleChange}
                  >
                    <option value="Freehold">Freehold</option>
                    <option value="Leasehold">Leasehold</option>
                  </select>
                </div>
              </div>
              <div className="col-md-6">
                <div className="mb-3">
                  <label className="form-label">Type of Structure</label>
                  <input 
                    type="text" 
                    className="form-control" 
                    name="typeOfStructure"
                    defaultValue="RCC"
                    onChange={handleChange}
                  />
                </div>
              </div>
            </div>

            <div className="row">
              <div className="col-md-6">
                <div className="mb-3">
                  <label className="form-label">Area of PLOT</label>
                  <input 
                    type="text" 
                    className="form-control" 
                    name="plotArea"
                    defaultValue="5000 SQFT"
                    onChange={handleChange}
                  />
                </div>
              </div>
              <div className="col-md-6">
                <div className="mb-3">
                  <label className="form-label">Total No of Floors</label>
                  <input 
                    type="text" 
                    className="form-control" 
                    name="totalFloors"
                    defaultValue="G+2"
                    onChange={handleChange}
                  />
                </div>
              </div>
            </div>

            <div className="row">
              <div className="col-md-6">
                <div className="mb-3">
                  <label className="form-label">Lift Facility</label>
                  <select 
                    className="form-select" 
                    name="liftFacility"
                    onChange={handleChange}
                  >
                    <option value="YES">YES</option>
                    <option value="NO">NO</option>
                  </select>
                </div>
              </div>
              <div className="col-md-6">
                <div className="mb-3">
                  <label className="form-label">Amenities</label>
                  <select 
                    className="form-select" 
                    name="amenities"
                    onChange={handleChange}
                  >
                    <option value="Average">Average</option>
                    <option value="Excellent">Excellent</option>
                    <option value="Good">Good</option>
                    <option value="Low">Low</option>
                    <option value="NA">NA</option>
                  </select>
                </div>
              </div>
            </div>

            <div className="row">
              <div className="col-md-6">
                <div className="mb-3">
                  <label className="form-label">Marketability</label>
                  <select 
                    className="form-select" 
                    name="marketability"
                    onChange={handleChange}
                  >
                    <option value="Average">Average</option>
                    <option value="Excellent">Excellent</option>
                    <option value="Good">Good</option>
                    <option value="Low">Low</option>
                  </select>
                </div>
              </div>
              <div className="col-md-6">
                <div className="mb-3">
                  <label className="form-label">View of the Property</label>
                  <input 
                    type="text" 
                    className="form-control" 
                    name="propertyView"
                    defaultValue="NORMAL"
                    onChange={handleChange}
                  />
                </div>
              </div>
            </div>

            <div className="row">
              <div className="col-md-6">
                <div className="mb-3">
                  <label className="form-label">Parking Facility</label>
                  <select 
                    className="form-select" 
                    name="parkingFacility"
                    onChange={handleChange}
                  >
                    <option value="YES">YES</option>
                    <option value="NO">NO</option>
                  </select>
                </div>
              </div>
              <div className="col-md-6">
                <div className="mb-3">
                  <label className="form-label">Type of Parking</label>
                  <select 
                    className="form-select" 
                    name="parkingType"
                    onChange={handleChange}
                  >
                    <option value="Open CP">Open CP</option>
                    <option value="Dependent CP">Dependent CP</option>
                    <option value="Covered CP">Covered CP</option>
                    <option value="Mechanical CP">Mechanical CP</option>
                  </select>
                </div>
              </div>
            </div>

            <div className="row">
              <div className="col-md-6">
                <div className="mb-3">
                  <label className="form-label">Quality of Construction</label>
                  <select 
                    className="form-select" 
                    name="constructionQuality"
                    onChange={handleChange}
                  >
                    <option value="Class A">Class A</option>
                    <option value="Class B">Class B</option>
                    <option value="Class C">Class C</option>
                    <option value="Class D">Class D</option>
                  </select>
                </div>
              </div>
              <div className="col-md-6">
                <div className="mb-3">
                  <label className="form-label">Shape of the Property</label>
                  <select 
                    className="form-select" 
                    name="propertyShape"
                    onChange={handleChange}
                  >
                    <option value="Regular">Regular</option>
                    <option value="Irregular">Irregular</option>
                  </select>
                </div>
              </div>
            </div>

            <div className="row">
              <div className="col-md-6">
                <div className="mb-3">
                  <label className="form-label">Placement of the Property</label>
                  <select 
                    className="form-select" 
                    name="propertyPlacement"
                    onChange={handleChange}
                  >
                    <option value="NE Facing Corner Plot">NE Facing Corner Plot</option>
                    <option value="Corner Plot">Corner Plot</option>
                    <option value="Intermittent Property">Intermittent Property</option>
                    <option value="South Facing">South Facing</option>
                  </select>
                </div>
              </div>
              <div className="col-md-6">
                <div className="mb-3">
                  <label className="form-label">Exteriors of the Property</label>
                  <select 
                    className="form-select" 
                    name="propertyExteriors"
                    onChange={handleChange}
                  >
                    <option value="Average">Average</option>
                    <option value="Poor">Poor</option>
                    <option value="Excellent">Excellent</option>
                    <option value="Good">Good</option>
                    <option value="Low">Low</option>
                  </select>
                </div>
              </div>
            </div>

            <div className="row">
              <div className="col-md-6">
                <div className="mb-3">
                  <label className="form-label">Interiors of the Property</label>
                  <select 
                    className="form-select" 
                    name="propertyInteriors"
                    onChange={handleChange}
                  >
                    <option value="Average">Average</option>
                    <option value="Poor">Poor</option>
                    <option value="Excellent">Excellent</option>
                    <option value="Good">Good</option>
                    <option value="Low">Low</option>
                  </select>
                </div>
              </div>
              <div className="col-md-6">
                <div className="mb-3">
                  <label className="form-label">Age of the Property</label>
                  <input 
                    type="number" 
                    className="form-control" 
                    name="propertyAge"
                    defaultValue="1"
                    onChange={handleChange}
                  />
                </div>
              </div>
            </div>

            <div className="row">
              <div className="col-md-6">
                <div className="mb-3">
                  <label className="form-label">Residual Age</label>
                  <input 
                    type="number" 
                    className="form-control" 
                    name="residualAge"
                    defaultValue="59"
                    onChange={handleChange}
                  />
                </div>
              </div>
              <div className="col-md-6">
                <div className="mb-3">
                  <label className="form-label">Source of age of Property</label>
                  <input 
                    type="text" 
                    className="form-control" 
                    name="ageSource"
                    defaultValue="COSTUMER"
                    onChange={handleChange}
                  />
                </div>
              </div>
            </div>

            <div className="row">
              <div className="col-md-6">
                <div className="mb-3">
                  <label className="form-label">Maintenance of the Property</label>
                  <select 
                    className="form-select" 
                    name="propertyMaintenance"
                    onChange={handleChange}
                  >
                    <option value="Average">Average</option>
                    <option value="Excellent">Excellent</option>
                    <option value="Good">Good</option>
                    <option value="Low">Low</option>
                  </select>
                </div>
              </div>
              <div className="col-md-6">
                <div className="mb-3">
                  <label className="form-label">Cautious Location</label>
                  <input 
                    type="text" 
                    className="form-control" 
                    name="cautiousLocation"
                    defaultValue="NA"
                    onChange={handleChange}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default PropertyDetails;