import React, { useState } from 'react';
import axios from 'axios';

// Importing the form sections
import BasicDetails from 'pages/BankForms/Adtiyaa/BasicDeatils';
import LocationDetails from 'pages/BankForms/Adtiyaa/LocationDetails';
import PropertyDetails from 'pages/BankForms/Adtiyaa/PropertyDetails';
import UnitsDetails from 'pages/BankForms/Adtiyaa/UnitsDeatils';
import BoundaryDetails from 'pages/BankForms/Adtiyaa/BoundaryDetails';
import OtherDetails from 'pages/BankForms/Adtiyaa/OthersDeatils';

const Index = () => {
  // States for holding data for each section
  const [formData, setFormData] = useState({
    BasicDetails: {},
    LocationDetails: {},
    PropertyDetails: {},
    UnitsDeatils: {},
    OthersDeatils: {},
    BoundaryDetails: {}
  });

  // Handle Data Change Dynamically: Updates state for each form section
  const handleDataChange = (section, data) => {
    setFormData(prevData => ({
      ...prevData,
      [section]: data
    }));
  };

  // Handle Submit Function: Sends data to backend
  const handleSubmitAll = async () => {
    try {
      const response = await axios.post('http://localhost:5000/api/aditya', formData, {
        headers: {
          'Content-Type': 'application/json',
        }
      });

      console.log('Full Response:', response);

      if (response.status === 200 || response.status === 201) {
        console.log('✅ Successfully Submitted:', response.data);
        alert('✅ Data successfully submitted!');

        // Reset the state after successful submission
        setFormData({
          BasicDetails: {},
          LocationDetails: {},
          PropertyDetails: {},
          UnitsDeatils: {},
          OthersDeatils: {},
          BoundaryDetails: {}
        });
      } else {
        console.error('Response Error:', response.data);
        alert('❌ Failed to submit data.');
      }
    } catch (error) {
      if (error.response) {
        console.error('Server responded with error:', error.response.data);
        alert('❌ Server error: ' + (error.response.data.message || 'Unknown server error'));
      } else if (error.request) {
        console.error('No response received:', error.request);
        alert('❌ No response from server.');
      } else {
        console.error('Error setting up request:', error.message);
        alert('❌ Error submitting data.');
      }
    }
  };

  return (
    <div className="container mt-4">
      <h3>Complete Valuation Report</h3>

      {/* Component to capture Basic Details */}
      <BasicDetails onDataChange={(data) => handleDataChange('BasicDetails', data)} initialData={formData.BasicDetails} />
      
      {/* Components for other sections */}
      <LocationDetails onDataChange={(data) => handleDataChange('LocationDetails', data)} />
      <PropertyDetails onDataChange={(data) => handleDataChange('PropertyDetails', data)} />
      <UnitsDetails onDataChange={(data) => handleDataChange('UnitsDeatils', data)} />
      <OtherDetails onDataChange={(data) => handleDataChange('OthersDeatils', data)} />
      <BoundaryDetails onDataChange={(data) => handleDataChange('BoundaryDetails', data)} />

      {/* Submit Button */}
      <div className="text-end mt-2 mb-2">
        <button className="btn btn-dark" onClick={handleSubmitAll}>
          Submit Report
        </button>
      </div>
    </div>
  );
};

export default Index;
  