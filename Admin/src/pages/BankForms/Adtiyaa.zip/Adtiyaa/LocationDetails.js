import React, { useState } from 'react';

const LocationDetails = ({ onDataChange }) => {
  const [isOpen, setIsOpen] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    onDataChange(prev => ({ ...prev, [name]: value }));
  };

  return (
    <div className="accordion-item mb-4">
      <div
        className="accordion-header p-3 border rounded"
        style={{ backgroundColor: "#30384B", cursor: "pointer" }}
        onClick={() => setIsOpen(!isOpen)}
      >
        <div className="d-flex justify-content-between align-items-center text-white">
          <h4 className="m-0">Location Details</h4>
          <button
            type="button"
            className="btn btn-light btn-sm"
            onClick={(e) => {
              e.stopPropagation();
              setIsOpen(!isOpen);
            }}
          >
            {isOpen ? "Close" : "Edit"}
          </button>
        </div>
      </div>
      {isOpen && (
        <div className="accordion-body p-3 border rounded mt-2" style={{ backgroundColor: "#f8f9fa" }}>
          <div className="card-body">
            <div className="mb-3">
              <label className="form-label">Property Address as Per TRF</label>
              <textarea
                className="form-control"
                name="propertyAddressTRF"
                defaultValue="PROPERTY IS PLOT NO.05(PART-1) AND PLOT NO. 05, IS LAND PART OF KHASRA NO.79,80,81,82,83/10/I/K,(NEW KHASRA NO. 79/10/I/4(S),80,81,82,83/10/I/4), SITUATED AT GRAM-MISROD,WARD NO.52, TEHSIL-KOLAR,DIST-BHOPAL,MP,462047"
                onChange={handleChange}
                rows="3"
              />
            </div>

            <div className="mb-3">
              <label className="form-label">Property Address as Per Visit</label>
              <textarea
                className="form-control"
                name="propertyAddressVisit"
                defaultValue="PROPERTY IS PLOT NO.05(PART-1) AND PLOT NO. 05, IS LAND PART OF KHASRA NO.79,80,81,82,83/10/I/K,(NEW KHASRA NO. 79/10/I/4(S),80,81,82,83/10/I/4), SITUATED AT GRAM-MISROD,WARD NO.52, TEHSIL-KOLAR,DIST-BHOPAL,MP,462047"
                onChange={handleChange}
                rows="3"
              />
            </div>

            <div className="mb-3">
              <label className="form-label">Property Address as Per Docs</label>
              <textarea
                className="form-control"
                name="propertyAddressDocs"
                defaultValue="PROPERTY IS PLOT NO.05(PART-1) AND PLOT NO. 05, IS LAND PART OF KHASRA NO.79,80,81,82,83/10/I/K,(NEW KHASRA NO. 79/10/I/4(S),80,81,82,83/10/I/4), SITUATED AT GRAM-MISROD,WARD NO.52, TEHSIL-KOLAR,DIST-BHOPAL,MP,462047"
                onChange={handleChange}
                rows="3"
              />
            </div>

            <div className="row">
              <div className="col-md-6">
                <div className="mb-3">
                  <label className="form-label">Main Locality</label>
                  <input
                    type="text"
                    className="form-control"
                    name="mainLocality"
                    defaultValue="MISROD"
                    onChange={handleChange}
                  />
                </div>
              </div>
              <div className="col-md-6">
                <div className="mb-3">
                  <label className="form-label">Sub Locality</label>
                  <input
                    type="text"
                    className="form-control"
                    name="subLocality"
                    defaultValue="MISROD ROAD"
                    onChange={handleChange}
                  />
                </div>
              </div>
            </div>

            <div className="row">
              <div className="col-md-6">
                <div className="mb-3">
                  <label className="form-label">Micro Location</label>
                  <input
                    type="text"
                    className="form-control"
                    name="microLocation"
                    defaultValue="CORAL WOODS"
                    onChange={handleChange}
                  />
                </div>
              </div>
              <div className="col-md-6">
                <div className="mb-3">
                  <label className="form-label">Landmark</label>
                  <input
                    type="text"
                    className="form-control"
                    name="landmark"
                    defaultValue="CORAL WOODS"
                    onChange={handleChange}
                  />
                </div>
              </div>
            </div>

            <div className="row">
              <div className="col-md-6">
                <div className="mb-3">
                  <label className="form-label">Latitude</label>
                  <input
                    type="text"
                    className="form-control"
                    name="latitude"
                    defaultValue="23.164204,"
                    onChange={handleChange}
                  />
                </div>
              </div>
              <div className="col-md-6">
                <div className="mb-3">
                  <label className="form-label">Longitude</label>
                  <input
                    type="text"
                    className="form-control"
                    name="longitude"
                    defaultValue="77.464502"
                    onChange={handleChange}
                  />
                </div>
              </div>
            </div>

            <div className="row">
              <div className="col-md-6">
                <div className="mb-3">
                  <label className="form-label">Type of Property</label>
                  <select
                    className="form-select"
                    name="propertyType"
                    defaultValue="RESIDENTIAL"
                    onChange={handleChange}
                  >
                    <option value="RESIDENTIAL">RESIDENTIAL</option>
                    <option value="COMMERCIAL">COMMERCIAL</option>
                    <option value="INDUSTRIAL">INDUSTRIAL</option>
                    <option value="INSTITUTIONAL">INSTITUTIONAL</option>
                    <option value="AGRICULTURE">AGRICULTURE</option>
                  </select>
                </div>
              </div>
              <div className="col-md-6">
                <div className="mb-3">
                  <label className="form-label">Current Usage</label>
                  <select
                    className="form-select"
                    name="currentUsage"
                    defaultValue="RESIDENTIAL"
                    onChange={handleChange}
                  >
                    <option value="RESIDENTIAL">RESIDENTIAL</option>
                    <option value="COMMERCIAL">COMMERCIAL</option>
                    <option value="INDUSTRIAL">INDUSTRIAL</option>
                    <option value="INSTITUTIONAL">INSTITUTIONAL</option>
                    <option value="AGRICULTURE">AGRICULTURE</option>
                  </select>
                </div>
              </div>
            </div>

            <div className="row">
              <div className="col-md-6">
                <div className="mb-3">
                  <label className="form-label">Previous Valuation Done?</label>
                  <select
                    className="form-select"
                    name="previousValuation"
                    defaultValue="No"
                    onChange={handleChange}
                  >
                    <option value="Yes">Yes</option>
                    <option value="No">No</option>
                  </select>
                </div>
              </div>
              <div className="col-md-6">
                <div className="mb-3">
                  <label className="form-label">If yes, when</label>
                  <input
                    type="text"
                    className="form-control"
                    name="previousValuationDate"
                    defaultValue="NA"
                    onChange={handleChange}
                  />
                </div>
              </div>
            </div>

            <div className="mb-3">
              <label className="form-label">Property Sub Type</label>
              <input
                type="text"
                className="form-control"
                name="propertySubType"
                defaultValue="HOUSE"
                onChange={handleChange}
              />
            </div>

            <div className="row">
              <div className="col-md-6">
                <div className="mb-3">
                  <label className="form-label">Locality</label>
                  <select
                    className="form-select"
                    name="locality"
                    defaultValue="Well Developed"
                    onChange={handleChange}
                  >
                    <option value="Well Developed">Well Developed</option>
                    <option value="Developing">Developing</option>
                    <option value="Under Develop">Under Develop</option>
                    <option value="Slum">Slum</option>
                  </select>
                </div>
              </div>
              <div className="col-md-6">
                <div className="mb-3">
                  <label className="form-label">Property Falling Within</label>
                  <select
                    className="form-select"
                    name="propertyFallingWithin"
                    defaultValue="Municipal Corporation"
                    onChange={handleChange}
                  >
                    <option value="Municipal Corporation">Municipal Corporation</option>
                    <option value="Gram Panchayat">Gram Panchayat</option>
                    <option value="Town Planning Authority">Town Planning Authority</option>
                    <option value="Development Authority">Development Authority</option>
                    <option value="Municipality">Municipality</option>
                  </select>
                </div>
              </div>
            </div>

            <div className="mb-3">
              <label className="form-label">Occupancy Level of the Surrounding</label>
              <select
                className="form-select"
                name="occupancyLevel"
                defaultValue="Densely Populated"
                onChange={handleChange}
              >
                <option value="Densely Populated">Densely Populated</option>
                <option value="Moderately Populated">Moderately Populated</option>
                <option value="Low Population density">Low Population density</option>
              </select>
            </div>

            <div className="mb-3">
              <label className="form-label">Condition of the Site of the Property</label>
              <select
                className="form-select"
                name="siteCondition"
                defaultValue="Well Developed"
                onChange={handleChange}
              >
                <option value="Well Developed">Well Developed</option>
                <option value="Developing">Developing</option>
                <option value="Under Developed">Under Developed</option>
              </select>
            </div>

            <div className="mb-3">
              <label className="form-label">Distance to Railway/Metro Station</label>
              <input
                type="text"
                className="form-control"
                name="distanceRailway"
                defaultValue="8 KM (RANKAMLAPATI Railway station)"
                onChange={handleChange}
              />
            </div>

            <div className="mb-3">
              <label className="form-label">Distance to Bus Stop</label>
              <input
                type="text"
                className="form-control"
                name="distanceBusStop"
                defaultValue="2 KM"
                onChange={handleChange}
              />
            </div>

            <div className="mb-3">
              <label className="form-label">Distance of Plot from Main Road</label>
              <select
                className="form-select"
                name="distanceMainRoad"
                defaultValue="Not Applicable (Prop on Mid Road)"
                onChange={handleChange}
              >
                <option value="Not Applicable (Prop on Mid Road)">Not Applicable (Prop on Mid Road)</option>
                <option value="Less than 200 m">Less than 200 m</option>
                <option value="200 to 500 m">200 to 500 m</option>
                <option value="above 500 m">above 500 m</option>
              </select>
            </div>

            <div className="mb-3">
              <label className="form-label">Distance from City Centre</label>
              <input
                type="text"
                className="form-control"
                name="distanceCityCentre"
                defaultValue="10 KMS"
                onChange={handleChange}
              />
            </div>

            <div className="mb-3">
              <label className="form-label">Distance from ABFL Branch</label>
              <input
                type="text"
                className="form-control"
                name="distanceABFLBranch"
                defaultValue="10 KMS"
                onChange={handleChange}
              />
            </div>

            <div className="mb-3">
              <label className="form-label">Width of the Approach Road</label>
              <select
                className="form-select"
                name="approachRoadWidth"
                defaultValue="Width 20 to 40 ft."
                onChange={handleChange}
              >
                <option value="Width >40 ft.">Width 40 ft.</option>
                <option value="Width 20 to 40 ft.">Width 20 to 40 ft.</option>
                <option value="Clear width<10ft">Clear width 10ft</option>
                <option value="Mud Road">Mud Road</option>
                <option value="Illegal Road (Without document)">Illegal Road (Without document)</option>
              </select>
            </div>

            <div className="row">
              <div className="col-md-4">
                <div className="mb-3">
                  <label className="form-label">Dimensions of the Property</label>
                  <input
                    type="text"
                    className="form-control"
                    name="propertyDimensions"
                    defaultValue="NA"
                    onChange={handleChange}
                  />
                </div>
              </div>
              <div className="col-md-4">
                <div className="mb-3">
                  <label className="form-label">NA</label>
                  <input
                    type="text"
                    className="form-control"
                    name="naField"
                    defaultValue="NA"
                    onChange={handleChange}
                  />
                </div>
              </div>
              <div className="col-md-4">
                <div className="mb-3">
                  <label className="form-label">Depth in Feet</label>
                  <input
                    type="text"
                    className="form-control"
                    name="depthInFeet"
                    defaultValue="NA"
                    onChange={handleChange}
                  />
                </div>
              </div>
            </div>

            <div className="row">
              <div className="col-md-6">
                <div className="mb-3">
                  <label className="form-label">Physical Approach to the Property</label>
                  <select
                    className="form-select"
                    name="physicalApproach"
                    defaultValue="Clear"
                    onChange={handleChange}
                  >
                    <option value="Clear">Clear</option>
                    <option value="Partially Clear">Partially Clear</option>
                    <option value="Not Clear">Not Clear</option>
                  </select>
                </div>
              </div>
              <div className="col-md-6">
                <div className="mb-3">
                  <label className="form-label">Legal Approach to the Property</label>
                  <select
                    className="form-select"
                    name="legalApproach"
                    defaultValue="Clear"
                    onChange={handleChange}
                  >
                    <option value="Clear">Clear</option>
                    <option value="Partially Clear">Partially Clear</option>
                    <option value="Not Clear">Not Clear</option>
                  </select>
                </div>
              </div>
            </div>

            <div className="mb-3">
              <label className="form-label">
                Any other features like board of other financier indicating mortgage, notice of Court/any authority which may affect the security
              </label>
              <select
                className="form-select"
                name="otherFeatures"
                defaultValue="NO"
                onChange={handleChange}
              >
                <option value="YES">YES</option>
                <option value="NO">NO</option>
              </select>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default LocationDetails;