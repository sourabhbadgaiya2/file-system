import React, { useState } from 'react';

const BoundaryDetails = ({ onDataChange }) => {
  const [isOpen, setIsOpen] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    onDataChange(prev => ({ ...prev, [name]: value }));
  };

  return (
    <div className="accordion-item mb-4">
      <div
        className="accordion-header p-3 border rounded"
        style={{ backgroundColor: "#30384B", cursor: "pointer" }}
        onClick={() => setIsOpen(!isOpen)}
      >
        <div className="d-flex justify-content-between align-items-center text-white">
          <h4 className="m-0">Boundary Details</h4>
          <button
            type="button"
            className="btn btn-light btn-sm"
            onClick={(e) => {
              e.stopPropagation();
              setIsOpen(!isOpen);
            }}
          >
            {isOpen ? "Close" : "Edit"}
          </button>
        </div>
      </div>
      {isOpen && (
        <div className="accordion-body p-3 border rounded mt-2" style={{ backgroundColor: "#f8f9fa" }}>
          <div className="card-body">
            <h5 className="mb-3">Boundary Detailing</h5>
            <div className="row mb-3">
              <div className="col-md-12">
                <table className="table table-bordered">
                  <thead>
                    <tr>
                      <th>Detailing</th>
                      <th>North</th>
                      <th>South</th>
                      <th>East</th>
                      <th>West</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>As per docs.</td>
                      <td>
                        <input 
                          type="text" 
                          className="form-control" 
                          name="northAsPerDocs"
                          defaultValue="HIMALAY RESIDENCY AND COLONY"
                          onChange={handleChange}
                        />
                      </td>
                      <td>
                        <input 
                          type="text" 
                          className="form-control" 
                          name="southAsPerDocs"
                          defaultValue="ROAD"
                          onChange={handleChange}
                        />
                      </td>
                      <td>
                        <input 
                          type="text" 
                          className="form-control" 
                          name="eastAsPerDocs"
                          defaultValue="REMAINING LAND PART OF SELIER/ REMAINING LAND PART OF SELIER"
                          onChange={handleChange}
                        />
                      </td>
                      <td>
                        <input 
                          type="text" 
                          className="form-control" 
                          name="westAsPerDocs"
                          defaultValue="PLOT NO.05/ OTHER PLOT"
                          onChange={handleChange}
                        />
                      </td>
                    </tr>
                    <tr>
                      <td>As per Actual</td>
                      <td>
                        <input 
                          type="text" 
                          className="form-control" 
                          name="northActual"
                          defaultValue="HIMALAY COLONY"
                          onChange={handleChange}
                        />
                      </td>
                      <td>
                        <input 
                          type="text" 
                          className="form-control" 
                          name="southActual"
                          defaultValue="ROAD"
                          onChange={handleChange}
                        />
                      </td>
                      <td>
                        <input 
                          type="text" 
                          className="form-control" 
                          name="eastActual"
                          defaultValue="OPEN PLOT"
                          onChange={handleChange}
                        />
                      </td>
                      <td>
                        <input 
                          type="text" 
                          className="form-control" 
                          name="westActual"
                          defaultValue="OPEN PLOT"
                          onChange={handleChange}
                        />
                      </td>
                    </tr>
                    <tr>
                      <td>Boundary Matching</td>
                      <td>
                        <input 
                          type="text" 
                          className="form-control" 
                          name="northBoundaryMatching"
                          onChange={handleChange}
                        />
                      </td>
                      <td>
                        <input 
                          type="text" 
                          className="form-control" 
                          name="southBoundaryMatching"
                          onChange={handleChange}
                        />
                      </td>
                      <td>
                        <input 
                          type="text" 
                          className="form-control" 
                          name="eastBoundaryMatching"
                          defaultValue="NO"
                          onChange={handleChange}
                        />
                      </td>
                      <td>
                        <input 
                          type="text" 
                          className="form-control" 
                          name="westBoundaryMatching"
                          onChange={handleChange}
                        />
                      </td>
                    </tr>
                    <tr>
                      <td>Remarks:</td>
                      <td>
                        <input 
                          type="text" 
                          className="form-control" 
                          name="northRemarks"
                          onChange={handleChange}
                        />
                      </td>
                      <td>
                        <input 
                          type="text" 
                          className="form-control" 
                          name="southRemarks"
                          onChange={handleChange}
                        />
                      </td>
                      <td>
                        <input 
                          type="text" 
                          className="form-control" 
                          name="eastRemarks"
                          onChange={handleChange}
                        />
                      </td>
                      <td>
                        <input 
                          type="text" 
                          className="form-control" 
                          name="westRemarks"
                          onChange={handleChange}
                        />
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>

            <div className="mb-3">
              <label className="form-label">Additional Remarks</label>
              <textarea 
                className="form-control" 
                name="additionalRemarks"
                rows="8"
                onChange={handleChange}
                defaultValue={`1. GIVEN XEROX COPY OF TWO SALE DEED IN FAVOUR OF 1) MR.CHOGMAL PATIDAR S.O LT.MR.RA.JARA PATIDAR, 2) MR.AMAN PATIDAR S/O MR.SANTOSH PATIDAR, 3) MR.ANMOJ. PATIDAR S/O MR.SANTOSH PATIDAR.

2. DURING PROPERTY VISIT MR. AMAN JI WAS MET AT THE PROPERTY HE IS CUSTOMER HIS CONTACT NO. 7049804167JIT WAS CLEARLY EXPLAINED TO HIM/HER THAT THE PROPERTY VISIT IS BEING DONE FOR VALUATION PURPOSE IN RELATION WITH LOAN PROPOSAL.

3. RATE HAS BEEN CONFIRM FROM LOCAL MARKET ENQUIRY.

4. PROPERTY IS SITUATED AT SURROUNDING AREA OF LOCALITY IS RESIDENTIAL ZONING.

5. AT SITE PROPERTY IS G+2 RESIDENTIAL HOUSE WHICH IS OCCUPIED BY OWNER

6. OBTAIN T AND CP LAYOUT PLAN MEMO NO. BPULP 8567/JPO4/29 ON DATED 15.03.2022 PROPERTY IS IDENTIFIED BY T AND CP LAYOUT 7.AS PER SITE BUILT UP AREA OF GF IS 2600 SOFT, FF IS 2600 SOFT, SF IS 800 SOFT. TOTAL BUILT UP AREA OF G+2 IS 6000 SOFT.

8. AS PER BOTH DEED AND AT SITE LAND AREA OF THE PROPERTY IS 5000 SOFT.

9. BUILDING PERMISSION AND MAP NOT OBTAIN. SAME IS REQUIRED.

10. LATEST PTR REQUIRED.

11. AS PER DEED LAND USES IS RESIDENTIAL.

12. BUILT-UP IS TAKEN ACTUAL AT SITE`}
              />
            </div>

            <div className="row">
              <div className="col-md-6">
                <div className="mb-3">
                  <label className="form-label">Name of the Engineer visited</label>
                  <input 
                    type="text" 
                    className="form-control" 
                    name="engineerName"
                    defaultValue="ER.ARBAZ"
                    onChange={handleChange}
                  />
                </div>
              </div>
              <div className="col-md-6">
                <div className="mb-3">
                  <label className="form-label">PHOTOGRAPHS OF PROPERTY</label>
                  <input 
                    type="text" 
                    className="form-control" 
                    name="propertyPhotos"
                    placeholder="Subject Property"
                    onChange={handleChange}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default BoundaryDetails;