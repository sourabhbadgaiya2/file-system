import React, { useState } from 'react';

const OtherDetails = ({ onDataChange }) => {
  const [isOpen, setIsOpen] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    onDataChange(prev => ({ ...prev, [name]: value }));
  };

  return (
    <div className="accordion-item mb-4">
      <div
        className="accordion-header p-3 border rounded"
        style={{ backgroundColor: "#30384B", cursor: "pointer" }}
        onClick={() => setIsOpen(!isOpen)}
      >
        <div className="d-flex justify-content-between align-items-center text-white">
          <h4 className="m-0">Other Details</h4>
          <button
            type="button"
            className="btn btn-light btn-sm"
            onClick={(e) => {
              e.stopPropagation();
              setIsOpen(!isOpen);
            }}
          >
            {isOpen ? "Close" : "Edit"}
          </button>
        </div>
      </div>
      {isOpen && (
        <div className="accordion-body p-3 border rounded mt-2" style={{ backgroundColor: "#f8f9fa" }}>
          <div className="card-body">
            <h5 className="mb-3">Setbacks</h5>
            <div className="row mb-3">
              <div className="col-md-12">
                <table className="table table-bordered">
                  <thead>
                    <tr>
                      <th>Direction</th>
                      <th>As per plan/Bye laws</th>
                      <th>Actual at site</th>
                      <th>Deviation</th>
                      <th>Remarks, if any</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>Front</td>
                      <td>
                        <input 
                          type="text" 
                          className="form-control" 
                          name="frontAsPerPlan"
                          defaultValue="M"
                          onChange={handleChange}
                        />
                      </td>
                      <td>
                        <input 
                          type="text" 
                          className="form-control" 
                          name="frontActual"
                          defaultValue="0 R"
                          onChange={handleChange}
                        />
                      </td>
                      <td>
                        <input 
                          type="text" 
                          className="form-control" 
                          name="frontDeviation"
                          onChange={handleChange}
                        />
                      </td>
                      <td>
                        <input 
                          type="text" 
                          className="form-control" 
                          name="frontRemarks"
                          onChange={handleChange}
                        />
                      </td>
                    </tr>
                    <tr>
                      <td>Side1 (Left)</td>
                      <td>
                        <input 
                          type="text" 
                          className="form-control" 
                          name="side1AsPerPlan"
                          defaultValue="M"
                          onChange={handleChange}
                        />
                      </td>
                      <td>
                        <input 
                          type="text" 
                          className="form-control" 
                          name="side1Actual"
                          defaultValue="0 R"
                          onChange={handleChange}
                        />
                      </td>
                      <td>
                        <input 
                          type="text" 
                          className="form-control" 
                          name="side1Deviation"
                          defaultValue="Usage Deviation"
                          onChange={handleChange}
                        />
                      </td>
                      <td>
                        <input 
                          type="text" 
                          className="form-control" 
                          name="side1Remarks"
                          onChange={handleChange}
                        />
                      </td>
                    </tr>
                    <tr>
                      <td>Side2 (Right)</td>
                      <td>
                        <input 
                          type="text" 
                          className="form-control" 
                          name="side2AsPerPlan"
                          defaultValue="M"
                          onChange={handleChange}
                        />
                      </td>
                      <td>
                        <input 
                          type="text" 
                          className="form-control" 
                          name="side2Actual"
                          defaultValue="0 R"
                          onChange={handleChange}
                        />
                      </td>
                      <td>
                        <input 
                          type="text" 
                          className="form-control" 
                          name="side2Deviation"
                          onChange={handleChange}
                        />
                      </td>
                      <td>
                        <input 
                          type="text" 
                          className="form-control" 
                          name="side2Remarks"
                          onChange={handleChange}
                        />
                      </td>
                    </tr>
                    <tr>
                      <td>Rear</td>
                      <td>
                        <input 
                          type="text" 
                          className="form-control" 
                          name="rearAsPerPlan"
                          defaultValue="M"
                          onChange={handleChange}
                        />
                      </td>
                      <td>
                        <input 
                          type="text" 
                          className="form-control" 
                          name="rearActual"
                          defaultValue="0 R"
                          onChange={handleChange}
                        />
                      </td>
                      <td>
                        <input 
                          type="text" 
                          className="form-control" 
                          name="rearDeviation"
                          onChange={handleChange}
                        />
                      </td>
                      <td>
                        <input 
                          type="text" 
                          className="form-control" 
                          name="rearRemarks"
                          onChange={handleChange}
                        />
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>

            <div className="row">
              <div className="col-md-4">
                <div className="mb-3">
                  <label className="form-label">Total Value</label>
                  <input 
                    type="number" 
                    className="form-control" 
                    name="totalValue"
                    defaultValue="2000000"
                    onChange={handleChange}
                  />
                </div>
              </div>
              <div className="col-md-4">
                <div className="mb-3">
                  <label className="form-label">Distress Value (80%)</label>
                  <input 
                    type="number" 
                    className="form-control" 
                    name="distressValue"
                    defaultValue="16800000"
                    onChange={handleChange}
                  />
                </div>
              </div>
              <div className="col-md-4">
                <div className="mb-3">
                  <label className="form-label">Insurance Value</label>
                  <input 
                    type="number" 
                    className="form-control" 
                    name="insuranceValue"
                    onChange={handleChange}
                  />
                </div>
              </div>
            </div>

            <div className="row">
              <div className="col-md-6">
                <div className="mb-3">
                  <label className="form-label">Government Value</label>
                  <input 
                    type="number" 
                    className="form-control" 
                    name="governmentValue"
                    onChange={handleChange}
                  />
                </div>
              </div>
              <div className="col-md-3">
                <div className="mb-3">
                  <label className="form-label">Percentage Completion</label>
                  <input 
                    type="text" 
                    className="form-control" 
                    name="percentageCompletion"
                    defaultValue="100%"
                    onChange={handleChange}
                  />
                </div>
              </div>
              <div className="col-md-3">
                <div className="mb-3">
                  <label className="form-label">Percentage Recommendation</label>
                  <input 
                    type="text" 
                    className="form-control" 
                    name="percentageRecommendation"
                    defaultValue="100%"
                    onChange={handleChange}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default OtherDetails;