import React, { useState } from 'react';

const UnitDetails = ({ onDataChange }) => {
  const [isOpen, setIsOpen] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    onDataChange(prev => ({ ...prev, [name]: value }));
  };

  return (
    <div className="accordion-item mb-4">
      <div
        className="accordion-header p-3 border rounded"
        style={{ backgroundColor: "#30384B", cursor: "pointer" }}
        onClick={() => setIsOpen(!isOpen)}
      >
        <div className="d-flex justify-content-between align-items-center text-white">
          <h4 className="m-0">Unit Details</h4>
          <button
            type="button"
            className="btn btn-light btn-sm"
            onClick={(e) => {
              e.stopPropagation();
              setIsOpen(!isOpen);
            }}
          >
            {isOpen ? "Close" : "Edit"}
          </button>
        </div>
      </div>
      {isOpen && (
        <div className="accordion-body p-3 border rounded mt-2" style={{ backgroundColor: "#f8f9fa" }}>
          <div className="card-body">
            <h5 className="mb-3">Accommodation/Unit Details</h5>
            
            <div className="row mb-3">
              <div className="col-md-12">
                <table className="table table-bordered">
                  <thead>
                    <tr>
                      <th>Building</th>
                      <th>Details</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>Ground Floor</td>
                      <td>
                        <input 
                          type="text" 
                          className="form-control" 
                          name="groundFloorDetails"
                          defaultValue="2R+2H+IK+3LB"
                          onChange={handleChange}
                        />
                      </td>
                    </tr>
                    <tr>
                      <td>FIRST FLOOR</td>
                      <td>
                        <input 
                          type="text" 
                          className="form-control" 
                          name="firstFloorDetails"
                          defaultValue="4R+IH+4LB"
                          onChange={handleChange}
                        />
                      </td>
                    </tr>
                    <tr>
                      <td>SECOND FLOOR</td>
                      <td>
                        <input 
                          type="text" 
                          className="form-control" 
                          name="secondFloorDetails"
                          defaultValue="IH"
                          onChange={handleChange}
                        />
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>

            <h5 className="mb-3">Document Availability</h5>
            <div className="row">
              <div className="col-md-6">
                <div className="mb-3">
                  <label className="form-label">Sale Deed/Allotment Letter</label>
                  <select 
                    className="form-select" 
                    name="saleDeed"
                    onChange={handleChange}
                  >
                    <option value="Fully Available">Fully Available</option>
                    <option value="Partially Available">Partially Available</option>
                    <option value="Not Available">Not Available</option>
                    <option value="Not Applicable">Not Applicable</option>
                  </select>
                </div>
                <div className="mb-3">
                  <label className="form-label">Details</label>
                  <input 
                    type="text" 
                    className="form-control" 
                    name="saleDeedDetails"
                    defaultValue="NA"
                    onChange={handleChange}
                  />
                </div>
              </div>
              <div className="col-md-6">
                <div className="mb-3">
                  <label className="form-label">Sanctioned Plan</label>
                  <select 
                    className="form-select" 
                    name="sanctionedPlan"
                    onChange={handleChange}
                  >
                    <option value="Fully Available">Fully Available</option>
                    <option value="Partially Available">Partially Available</option>
                    <option value="Not Available">Not Available</option>
                    <option value="Not Applicable">Not Applicable</option>
                  </select>
                </div>
                <div className="mb-3">
                  <label className="form-label">Details</label>
                  <input 
                    type="text" 
                    className="form-control" 
                    name="sanctionedPlanDetails"
                    defaultValue="NA"
                    onChange={handleChange}
                  />
                </div>
              </div>
            </div>

            <div className="row">
              <div className="col-md-6">
                <div className="mb-3">
                  <label className="form-label">CC/OC</label>
                  <select 
                    className="form-select" 
                    name="ccOc"
                    onChange={handleChange}
                  >
                    <option value="Fully Available">Fully Available</option>
                    <option value="Partially Available">Partially Available</option>
                    <option value="Not Available">Not Available</option>
                    <option value="Not Applicable">Not Applicable</option>
                  </select>
                </div>
                <div className="mb-3">
                  <label className="form-label">Details</label>
                  <input 
                    type="text" 
                    className="form-control" 
                    name="ccOcDetails"
                    defaultValue="NA"
                    onChange={handleChange}
                  />
                </div>
              </div>
              <div className="col-md-6">
                <div className="mb-3">
                  <label className="form-label">Agreement to Sale</label>
                  <select 
                    className="form-select" 
                    name="agreementToSale"
                    onChange={handleChange}
                  >
                    <option value="Fully Available">Fully Available</option>
                    <option value="Partially Available">Partially Available</option>
                    <option value="Not Available">Not Available</option>
                    <option value="Not Applicable">Not Applicable</option>
                  </select>
                </div>
                <div className="mb-3">
                  <label className="form-label">Details</label>
                  <input 
                    type="text" 
                    className="form-control" 
                    name="agreementToSaleDetails"
                    defaultValue="NA"
                    onChange={handleChange}
                  />
                </div>
              </div>
            </div>

            <div className="row">
              <div className="col-md-6">
                <div className="mb-3">
                  <label className="form-label">Mutation/Possession Letter</label>
                  <select 
                    className="form-select" 
                    name="mutationPossession"
                    onChange={handleChange}
                  >
                    <option value="Fully Available">Fully Available</option>
                    <option value="Partially Available">Partially Available</option>
                    <option value="Not Available">Not Available</option>
                    <option value="Not Applicable">Not Applicable</option>
                  </select>
                </div>
                <div className="mb-3">
                  <label className="form-label">Details</label>
                  <input 
                    type="text" 
                    className="form-control" 
                    name="mutationPossessionDetails"
                    defaultValue="NA"
                    onChange={handleChange}
                  />
                </div>
              </div>
              <div className="col-md-6">
                <div className="mb-3">
                  <label className="form-label">Tax Receipt</label>
                  <select 
                    className="form-select" 
                    name="taxReceipt"
                    onChange={handleChange}
                  >
                    <option value="Fully Available">Fully Available</option>
                    <option value="Partially Available">Partially Available</option>
                    <option value="Not Available">Not Available</option>
                    <option value="Not Applicable">Not Applicable</option>
                  </select>
                </div>
                <div className="mb-3">
                  <label className="form-label">Details</label>
                  <input 
                    type="text" 
                    className="form-control" 
                    name="taxReceiptDetails"
                    defaultValue="NA"
                    onChange={handleChange}
                  />
                </div>
              </div>
            </div>

            <div className="row">
              <div className="col-md-6">
                <div className="mb-3">
                  <label className="form-label">Electricity Bill</label>
                  <select 
                    className="form-select" 
                    name="electricityBill"
                    onChange={handleChange}
                  >
                    <option value="Fully Available">Fully Available</option>
                    <option value="Partially Available">Partially Available</option>
                    <option value="Not Available">Not Available</option>
                    <option value="Not Applicable">Not Applicable</option>
                  </select>
                </div>
                <div className="mb-3">
                  <label className="form-label">Details</label>
                  <input 
                    type="text" 
                    className="form-control" 
                    name="electricityBillDetails"
                    defaultValue="NA"
                    onChange={handleChange}
                  />
                </div>
              </div>
              <div className="col-md-6">
                <div className="mb-3">
                  <label className="form-label">Conversion</label>
                  <select 
                    className="form-select" 
                    name="conversion"
                    onChange={handleChange}
                  >
                    <option value="Fully Available">Fully Available</option>
                    <option value="Partially Available">Partially Available</option>
                    <option value="Not Available">Not Available</option>
                    <option value="Not Applicable">Not Applicable</option>
                  </select>
                </div>
                <div className="mb-3">
                  <label className="form-label">Details</label>
                  <input 
                    type="text" 
                    className="form-control" 
                    name="conversionDetails"
                    defaultValue="NA"
                    onChange={handleChange}
                  />
                </div>
              </div>
            </div>

            <h5 className="mb-3 mt-4">Built Up Area</h5>
            <div className="row mb-3">
              <div className="col-md-12">
                <table className="table table-bordered">
                  <thead>
                    <tr>
                      <th>Floor</th>
                      <th>As per Site</th>
                      <th>As per Plan/FAR</th>
                      <th>Deviations</th>
                      <th>Remarks</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>Ground Floor</td>
                      <td>
                        <input 
                          type="number" 
                          className="form-control" 
                          name="groundFloorArea"
                          defaultValue="2600"
                          onChange={handleChange}
                        />
                      </td>
                      <td>
                        <select 
                          className="form-select" 
                          name="groundFloorPlanMatch"
                          onChange={handleChange}
                        >
                          <option value="Yes">Yes</option>
                          <option value="No">No</option>
                        </select>
                      </td>
                      <td>
                        <input 
                          type="text" 
                          className="form-control" 
                          name="groundFloorDeviations"
                          onChange={handleChange}
                        />
                      </td>
                      <td>
                        <input 
                          type="text" 
                          className="form-control" 
                          name="groundFloorRemarks"
                          onChange={handleChange}
                        />
                      </td>
                    </tr>
                    <tr>
                      <td>FIRST FLOOR</td>
                      <td>
                        <input 
                          type="number" 
                          className="form-control" 
                          name="firstFloorArea"
                          defaultValue="2600"
                          onChange={handleChange}
                        />
                      </td>
                      <td>
                        <select 
                          className="form-select" 
                          name="firstFloorPlanMatch"
                          onChange={handleChange}
                        >
                          <option value="Yes">Yes</option>
                          <option value="No">No</option>
                        </select>
                      </td>
                      <td>
                        <input 
                          type="text" 
                          className="form-control" 
                          name="firstFloorDeviations"
                          onChange={handleChange}
                        />
                      </td>
                      <td>
                        <input 
                          type="text" 
                          className="form-control" 
                          name="firstFloorRemarks"
                          onChange={handleChange}
                        />
                      </td>
                    </tr>
                    <tr>
                      <td>SECOND FLOOR</td>
                      <td>
                        <input 
                          type="number" 
                          className="form-control" 
                          name="secondFloorArea"
                          defaultValue="800"
                          onChange={handleChange}
                        />
                      </td>
                      <td>
                        <input 
                          type="text" 
                          className="form-control" 
                          name="secondFloorPlanMatch"
                          onChange={handleChange}
                        />
                      </td>
                      <td>
                        <input 
                          type="text" 
                          className="form-control" 
                          name="secondFloorDeviations"
                          onChange={handleChange}
                        />
                      </td>
                      <td>
                        <input 
                          type="text" 
                          className="form-control" 
                          name="secondFloorRemarks"
                          onChange={handleChange}
                        />
                      </td>
                    </tr>
                    <tr>
                      <td>Total</td>
                      <td>
                        <input 
                          type="number" 
                          className="form-control" 
                          name="totalArea"
                          defaultValue="6000"
                          onChange={handleChange}
                        />
                      </td>
                      <td>
                        <select 
                          className="form-select" 
                          name="totalPlanMatch"
                          onChange={handleChange}
                        >
                          <option value="Yes">Yes</option>
                          <option value="No">No</option>
                        </select>
                      </td>
                      <td>
                        <input 
                          type="text" 
                          className="form-control" 
                          name="totalDeviations"
                          onChange={handleChange}
                        />
                      </td>
                      <td>
                        <input 
                          type="text" 
                          className="form-control" 
                          name="totalRemarks"
                          onChange={handleChange}
                        />
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>

            <h5 className="mb-3">Detailing</h5>
            <div className="row mb-3">
              <div className="col-md-12">
                <table className="table table-bordered">
                  <thead>
                    <tr>
                      <th>Item</th>
                      <th>Area in Sqft</th>
                      <th>Rate per Sqft</th>
                      <th>Value</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>Plot Area (in Deed)</td>
                      <td>
                        <input 
                          type="number" 
                          className="form-control" 
                          name="plotAreaDeed"
                          defaultValue="5000"
                          onChange={handleChange}
                        />
                      </td>
                      <td>
                        <input 
                          type="number" 
                          className="form-control" 
                          name="plotRateDeed"
                          defaultValue="2400"
                          onChange={handleChange}
                        />
                      </td>
                      <td>
                        <input 
                          type="number" 
                          className="form-control" 
                          name="plotValueDeed"
                          defaultValue="12000000"
                          onChange={handleChange}
                        />
                      </td>
                    </tr>
                    <tr>
                      <td>Plot Area (as per physical)</td>
                      <td>
                        <input 
                          type="number" 
                          className="form-control" 
                          name="plotAreaPhysical"
                          defaultValue="5000"
                          onChange={handleChange}
                        />
                      </td>
                      <td>
                        <input 
                          type="number" 
                          className="form-control" 
                          name="plotRatePhysical"
                          defaultValue="2400"
                          onChange={handleChange}
                        />
                      </td>
                      <td>
                        <input 
                          type="number" 
                          className="form-control" 
                          name="plotValuePhysical"
                          defaultValue="12000000"
                          onChange={handleChange}
                        />
                      </td>
                    </tr>
                    <tr>
                      <td>Carpet Area (as per plan)</td>
                      <td>
                        <input 
                          type="number" 
                          className="form-control" 
                          name="carpetAreaPlan"
                          defaultValue="0"
                          onChange={handleChange}
                        />
                      </td>
                      <td>
                        <input 
                          type="number" 
                          className="form-control" 
                          name="carpetRatePlan"
                          defaultValue="0"
                          onChange={handleChange}
                        />
                      </td>
                      <td>
                        <input 
                          type="number" 
                          className="form-control" 
                          name="carpetValuePlan"
                          defaultValue="0"
                          onChange={handleChange}
                        />
                      </td>
                    </tr>
                    <tr>
                      <td>Carpet Area (as per measurement)</td>
                      <td>
                        <input 
                          type="number" 
                          className="form-control" 
                          name="carpetAreaMeasurement"
                          defaultValue="0"
                          onChange={handleChange}
                        />
                      </td>
                      <td>
                        <input 
                          type="number" 
                          className="form-control" 
                          name="carpetRateMeasurement"
                          defaultValue="0"
                          onChange={handleChange}
                        />
                      </td>
                      <td>
                        <input 
                          type="number" 
                          className="form-control" 
                          name="carpetValueMeasurement"
                          defaultValue="0"
                          onChange={handleChange}
                        />
                      </td>
                    </tr>
                    <tr>
                      <td>Built Up Area (as per Norms)</td>
                      <td>
                        <input 
                          type="number" 
                          className="form-control" 
                          name="builtUpAreaNorms"
                          onChange={handleChange}
                        />
                      </td>
                      <td>
                        <input 
                          type="number" 
                          className="form-control" 
                          name="builtUpRateNorms"
                          defaultValue="0"
                          onChange={handleChange}
                        />
                      </td>
                      <td>
                        <input 
                          type="number" 
                          className="form-control" 
                          name="builtUpValueNorms"
                          defaultValue="0"
                          onChange={handleChange}
                        />
                      </td>
                    </tr>
                    <tr>
                      <td>Built Up Area (as per measurement)</td>
                      <td>
                        <input 
                          type="number" 
                          className="form-control" 
                          name="builtUpAreaMeasurement"
                          defaultValue="6000"
                          onChange={handleChange}
                        />
                      </td>
                      <td>
                        <input 
                          type="number" 
                          className="form-control" 
                          name="builtUpRateMeasurement"
                          defaultValue="1500"
                          onChange={handleChange}
                        />
                      </td>
                      <td>
                        <input 
                          type="number" 
                          className="form-control" 
                          name="builtUpValueMeasurement"
                          defaultValue="9000000"
                          onChange={handleChange}
                        />
                      </td>
                    </tr>
                    <tr>
                      <td>Super Built-Up Area</td>
                      <td>
                        <input 
                          type="number" 
                          className="form-control" 
                          name="superBuiltUpArea"
                          defaultValue="0"
                          onChange={handleChange}
                        />
                      </td>
                      <td>
                        <input 
                          type="number" 
                          className="form-control" 
                          name="superBuiltUpRate"
                          defaultValue="0"
                          onChange={handleChange}
                        />
                      </td>
                      <td>
                        <input 
                          type="number" 
                          className="form-control" 
                          name="superBuiltUpValue"
                          defaultValue="0"
                          onChange={handleChange}
                        />
                      </td>
                    </tr>
                    <tr>
                      <td>Car Park</td>
                      <td>
                        <input 
                          type="number" 
                          className="form-control" 
                          name="carParkArea"
                          defaultValue="0"
                          onChange={handleChange}
                        />
                      </td>
                      <td>
                        <input 
                          type="number" 
                          className="form-control" 
                          name="carParkRate"
                          defaultValue="0"
                          onChange={handleChange}
                        />
                      </td>
                      <td>
                        <input 
                          type="number" 
                          className="form-control" 
                          name="carParkValue"
                          defaultValue="0"
                          onChange={handleChange}
                        />
                      </td>
                    </tr>
                    <tr>
                      <td>Amenities</td>
                      <td>
                        <input 
                          type="number" 
                          className="form-control" 
                          name="amenitiesArea"
                          defaultValue="0"
                          onChange={handleChange}
                        />
                      </td>
                      <td>
                        <input 
                          type="number" 
                          className="form-control" 
                          name="amenitiesRate"
                          defaultValue="0"
                          onChange={handleChange}
                        />
                      </td>
                      <td>
                        <input 
                          type="number" 
                          className="form-control" 
                          name="amenitiesValue"
                          defaultValue="0"
                          onChange={handleChange}
                        />
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default UnitDetails;