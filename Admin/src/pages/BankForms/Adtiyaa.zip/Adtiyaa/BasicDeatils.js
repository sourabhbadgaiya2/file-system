import React, { useState } from 'react';

const BasicDetails = ({ onDataChange }) => {
  const [isOpen, setIsOpen] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    onDataChange(prev => ({ ...prev, [name]: value }));
  };

  return (
    <div className="accordion-item mb-4">
      <div
        className="accordion-header p-3 border rounded"
        style={{ backgroundColor: "#30384B", cursor: "pointer" }}
        onClick={() => setIsOpen(!isOpen)}
      >
        <div className="d-flex justify-content-between align-items-center text-white">
          <h4 className="m-0">Basic Details</h4>
          <button
            type="button"
            className="btn btn-light btn-sm"
            onClick={(e) => {
              e.stopPropagation();
              setIsOpen(!isOpen);
            }}
          >
            {isOpen ? "Close" : "Edit"}
          </button>
        </div>
      </div>
      {isOpen && (
        <div className="accordion-body p-3 border rounded mt-2" style={{ backgroundColor: "#f8f9fa" }}>
          <div className="card-body">
            <div className="row">
              <div className="col-md-6">
                <div className="mb-3">
                  <label className="form-label">Name of the Valuer</label>
                  <input 
                    type="text" 
                    className="form-control" 
                    name="valuerName"
                  
                    onChange={handleChange}
                  />
                </div>
              </div>
              <div className="col-md-6">
                <div className="mb-3">
                  <label className="form-label">Name of the Client</label>
                  <input 
                    type="text" 
                    className="form-control" 
                    name="clientName"
                  
                    onChange={handleChange}
                  />
                </div>
              </div>
            </div>

            <div className="row">
              <div className="col-md-4">
                <div className="mb-3">
                  <label className="form-label">Initiation Date</label>
                  <input 
                    type="date" 
                    className="form-control" 
                    name="initiationDate"
                    defaultValue="2025-02-06"
                    onChange={handleChange}
                  />
                </div>
              </div>
              <div className="col-md-4">
                <div className="mb-3">
                  <label className="form-label">Vertical</label>
                  <input 
                    type="text" 
                    className="form-control" 
                    name="vertical"
                    defaultValue="STSL+"
                    onChange={handleChange}
                  />
                </div>
              </div>
              <div className="col-md-4">
                <div className="mb-3">
                  <label className="form-label">Visit Date</label>
                  <input 
                    type="date" 
                    className="form-control" 
                    name="visitDate"
                    defaultValue="2025-02-06"
                    onChange={handleChange}
                  />
                </div>
              </div>
            </div>

            <div className="mb-3">
              <label className="form-label">Case Reference Number</label>
              <input 
                type="text" 
                className="form-control" 
                name="caseReferenceNumber"
                defaultValue="STSL00000054129"
                onChange={handleChange}
              />
            </div>

            <div className="mb-3">
              <label className="form-label">Name of the Property Owner(s)</label>
              <textarea 
                className="form-control" 
                name="propertyOwners"
                defaultValue="1.) MR.CHOGMAL PATIDAR S.O LT.MR.RAJARA PATIDAR, 2.) MR.AMAN PATIDAR S/O MR.SANTOSH PATIDAR, 3.) MR.ANMOL PATIDAR S/O MR.SANTOSH PATIDAR."
                onChange={handleChange}
                rows="3"
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default BasicDetails;